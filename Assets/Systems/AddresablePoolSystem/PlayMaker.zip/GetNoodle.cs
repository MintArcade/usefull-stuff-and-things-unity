using UnityEngine;
using UnityEngine.AddressableAssets;

namespace HutongGames.PlayMaker.Actions
{

	[ActionCategory("AddresablePool")]
	[Tooltip("Noodle is just like a regular game object, but it is taken from the addresable pool by name asynchronously. Don't forget to have AddresablePoolManager Game object and script and addresable groups all build correctly")]
	public class GetNoodle : FsmStateAction
	{
		[Tooltip("Addresable Name of the gameo bject in the pool")]
		public FsmString addresableName;

		[Tooltip("Optional Parent.")]
		public FsmGameObject parent;

		[Tooltip("Optional Spawn Point.")]
		public FsmGameObject spawnPoint;

		[ActionSection("Result")]
		[Tooltip("Pool Noodle")]
		public FsmGameObject poolNoodle;

		// Code that runs on entering the state.
		public override void OnEnter()
		{
			Get();
		}

		private async void Get()
		{
			GameObject g = null;

			g = await AddresablePool.current.Get(addresableName.Value);

			if (g!= null)
			{
				poolNoodle.Value = g;
				if (parent.Value != null)
				{
					g.transform.SetParent(parent.Value.transform, true);
				}
				if (spawnPoint.Value != null)
				{
					g.transform.position = spawnPoint.Value.transform.position;
				}
				Finish();
			}
			
		}
	}
}
