using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{

	[ActionCategory("AddresablePool")]
	public class ReturnNoodle : FsmStateAction
	{
		[RequiredField]
		//[CheckForComponent(typeof(PoolNoodle))]
		[Tooltip("Parent transform")]
		public FsmOwnerDefault poolNoodles;

		PoolNoodle[] noodles;

		// Code that runs on entering the state.
		public override void OnEnter()
		{
			noodles = poolNoodles.GameObject.Value.GetComponentsInChildren<PoolNoodle>(true);
			foreach (var item in noodles)
			{
				item.Return();
			}

			Finish();
		}
	}
}
